TECH_KEYWORDS = [
    "Python",
    "JavaScript",
    "React",
    "Next.js",
    "FastAPI",
    "Node.js",
    "Machine Learning",
    "AI",
    "SQL",
    "Docker",
    "AWS"
]


def match_keywords(skills: list):
    """
    Matches extracted skills against common ATS keywords.
    """
    matched = [skill for skill in skills if skill in TECH_KEYWORDS]
    return matched


def keyword_score(skills: list):
    """
    Calculates ATS keyword-based score.
    """
    matched = match_keywords(skills)
    score = len(matched) * 5
    return min(score, 50)
