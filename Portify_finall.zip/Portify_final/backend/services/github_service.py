import os
import requests
from dotenv import load_dotenv

load_dotenv()

GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")


def fetch_repos(username: str):
    headers = {}

    if GITHUB_TOKEN:
        headers["Authorization"] = f"Bearer {GITHUB_TOKEN}"

    url = f"https://api.github.com/users/{username}/repos"

    response = requests.get(url, headers=headers)

    if response.status_code != 200:
        return []

    return response.json()
