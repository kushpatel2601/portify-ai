from api.generate import router
import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = FastAPI(
    title="Portify API",
    version="1.0.0"
)

# ✅ Allow frontend connection
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Import router AFTER creating app
app.include_router(router)

# Test route


@app.get("/")
def root():
    return {
        "message": "🚀 Portify Backend Running",
        "environment": os.getenv("APP_ENV", "development")
    }


@app.get("/health")
def health():
    return {"status": "ok"}
