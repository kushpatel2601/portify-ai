from pydantic import BaseModel
from typing import List


class Project(BaseModel):
    name: str
    description: str
    stars: int
    url: str


class Portfolio(BaseModel):
    username: str
    headline: str
    about: str
    skills: List[str]
    projects: List[Project]
    ats_score: int
