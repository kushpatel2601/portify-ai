from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from agents.repo_analyzer import analyze_repos
from agents.storytelling_agent import generate_about_story, generate_project_story
from agents.ats_scorer import calculate_ats
from services.github_service import fetch_repos

router = APIRouter()


# ===============================
# Request Schema
# ===============================
class GenerateRequest(BaseModel):
    github_username: str


# ===============================
# Generate Portfolio Endpoint
# ===============================
@router.post("/generate")
def generate_portfolio(data: GenerateRequest):
    username = data.github_username.strip()

    if not username:
        raise HTTPException(
            status_code=400, detail="GitHub username is required")

    # 1️⃣ Fetch GitHub Repositories
    repos = fetch_repos(username)

    if not repos:
        raise HTTPException(
            status_code=404,
            detail="No repositories found or GitHub user does not exist"
        )

    # 2️⃣ Analyze Repositories
    analysis = analyze_repos(repos)

    skills = analysis.get("skills", [])
    projects_raw = analysis.get("projects", [])

    # 3️⃣ Generate AI Storytelling Content
    about = generate_about_story(username, skills)

    projects = []
    for project in projects_raw:
        story = generate_project_story(project)

        projects.append({
            "name": project["name"],
            "description": story,
            "language": project["language"],
            "stars": project["stars"],
            "url": project["url"]
        })

    # 4️⃣ Calculate ATS Score
    ats_score = calculate_ats(skills, projects)

    # 5️⃣ Generate Headline (Simple Intelligent Version)
    if skills:
        headline = f"{skills[0]} Developer | Skilled in {', '.join(skills[:4])}"
    else:
        headline = "Full-Stack Developer | Building Scalable Applications"

    # 6️⃣ Final Response
    return {
        "username": username,
        "headline": headline,
        "about": about,
        "skills": skills,
        "projects": projects,
        "ats_score": ats_score
    }
