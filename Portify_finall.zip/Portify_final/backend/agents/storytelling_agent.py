from services.llm_service import call_llm
from utils.prompt_templates import about_prompt, project_prompt


def clean_response(text: str) -> str:
    """
    Cleans unwanted formatting like quotes or explanations.
    """
    if not text:
        return ""

    text = text.strip()

    # Remove unwanted intro phrases
    unwanted_phrases = [
        "Here's a",
        "Here is a",
        "Below is",
        "Sure,",
        "\"",
    ]

    for phrase in unwanted_phrases:
        text = text.replace(phrase, "")

    return text.strip()


def generate_about_story(username: str, skills: list):
    """
    Generates a professional About section using LLM.
    Falls back to rule-based content if LLM fails.
    """
    try:
        prompt = about_prompt(username, skills)
        response = call_llm(prompt)
        return clean_response(response)

    except Exception:
        return (
            f"{username} is a passionate developer skilled in "
            f"{', '.join(skills[:5])}. Focused on building scalable, "
            "real-world software solutions."
        )


def generate_project_story(project: dict):
    """
    Converts raw GitHub repo data into recruiter-friendly description.
    """
    try:
        prompt = project_prompt(project)
        response = call_llm(prompt)
        return clean_response(response)

    except Exception:
        return (
            f"{project.get('name')} is a practical software project "
            "demonstrating strong development and problem-solving skills."
        )


def generate_headline(skills: list):
    """
    Generates a clean professional headline.
    """
    try:
        if not skills:
            return "Full Stack Developer"

        prompt = f"""
        Generate ONLY a short professional headline (max 12 words).
        Do not include explanations.
        Skills: {', '.join(skills[:5])}
        """

        response = call_llm(prompt)
        return clean_response(response)

    except Exception:
        if skills:
            return f"{skills[0]} Developer | Skilled in {', '.join(skills[:3])}"
        return "Full Stack Developer"
