from services.llm_service import call_llm
from utils.prompt_templates import about_prompt, headline_prompt


def generate_about(username, skills):
    return call_llm(about_prompt(username, skills))


def generate_headline(skills):
    return call_llm(headline_prompt(skills))
