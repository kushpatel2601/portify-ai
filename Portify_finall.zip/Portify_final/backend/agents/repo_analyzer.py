from collections import Counter


def analyze_repos(repos: list):
    """
    Dynamically analyze GitHub repositories.
    Extract:
    - Top languages (skills)
    - Project metadata
    """

    if not repos:
        return {
            "skills": [],
            "projects": []
        }

    language_counter = Counter()
    projects = []

    for repo in repos:
        language = repo.get("language")
        if language:
            language_counter[language] += 1

        projects.append({
            "name": repo.get("name"),
            "description": repo.get("description") or "No description provided.",
            "language": language or "Not specified",
            "stars": repo.get("stargazers_count", 0),
            "url": repo.get("html_url")
        })

    # Get top 6 languages dynamically
    top_skills = [lang for lang, _ in language_counter.most_common(6)]

    return {
        "skills": top_skills,
        "projects": projects[:6]  # Limit to top 6 repos
    }
