def calculate_ats(skills, projects):
    score = 50
    score += min(len(skills) * 5, 30)
    score += min(len(projects) * 3, 20)
    return min(score, 100)
