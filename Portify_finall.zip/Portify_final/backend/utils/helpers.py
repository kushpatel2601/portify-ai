def safe_list(value):
    """
    Ensures returned value is always a list.
    """
    if isinstance(value, list):
        return value
    return []


def normalize_skills(skills: list):
    """
    Removes duplicates and formats skills consistently.
    """
    return list(set(skill.strip() for skill in skills if skill))


def clamp_score(score: int):
    """
    Ensures ATS score remains between 0 and 100.
    """
    return max(0, min(score, 100))
