# ===============================
# ABOUT PROMPT
# ===============================

def about_prompt(username: str, skills: list):
    return f"""
Write a professional portfolio 'About Me' section for a developer.

GitHub Username: {username}
Skills: {', '.join(skills)}

Make it:
- Professional
- Recruiter friendly
- 4-5 sentences
- Confident but not arrogant
- Impact focused
"""


# ===============================
# PROJECT PROMPT
# ===============================

def project_prompt(project: dict):
    return f"""
Write a recruiter-friendly project description.

Project Name: {project.get("name")}
Primary Language: {project.get("language")}
Stars: {project.get("stars")}
Description: {project.get("description", "")}

Make it:
- Professional
- Clear impact
- 2-3 sentences
- Highlight technical value
"""
