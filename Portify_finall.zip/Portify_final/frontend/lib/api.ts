export async function generatePortfolio(username: string) {
  try {
    const res = await fetch(
      `${process.env.NEXT_PUBLIC_BACKEND_URL}/generate`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ github_username: username }),
      }
    );

    console.log("STATUS:", res.status);

    if (!res.ok) {
      const errorText = await res.text();
      console.error("Backend error:", errorText);
      throw new Error(errorText);
    }

    const data = await res.json();
    console.log("DATA:", data);

    return data;
  } catch (error) {
    console.error("Fetch error:", error);
    throw error;
  }
}
