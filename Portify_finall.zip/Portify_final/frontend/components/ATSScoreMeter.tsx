export default function ATSScoreMeter({ score }: { score: number }) {
  return (
    <div className="bg-slate-700 px-6 py-4 rounded-xl shadow-lg text-center">
      <p className="text-lg font-semibold">ATS Score</p>
      <p className="text-3xl font-bold text-green-400 mt-2">
        {score}/100
      </p>
    </div>
  );
}
