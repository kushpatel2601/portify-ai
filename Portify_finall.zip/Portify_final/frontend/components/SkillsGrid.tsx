export default function SkillsGrid({ skills }: { skills: string[] }) {
  return (
    <div className="flex flex-wrap gap-4">
      {skills.map((skill, index) => (
        <span
          key={index}
          className="px-4 py-2 bg-blue-600 rounded-full text-white text-sm font-medium shadow-md hover:bg-blue-500 transition"
        >
          {skill}
        </span>
      ))}
    </div>
  );
}
