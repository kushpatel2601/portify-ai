export default function Navbar() {
  return (
    <nav className="p-4 bg-white shadow">
      <strong>Portify</strong>
    </nav>
  );
}
