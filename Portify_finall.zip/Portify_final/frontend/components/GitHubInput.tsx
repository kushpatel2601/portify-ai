"use client";

import { useRouter } from "next/navigation";
import { generatePortfolio } from "../lib/api";
import { useState } from "react";

export default function GitHubInput() {
  const [username, setUsername] = useState("");
  const router = useRouter();

  const handleSubmit = async () => {
    const data = await generatePortfolio(username);
    localStorage.setItem("portfolio", JSON.stringify(data));
    router.push("/portfolio");
  };

  return (
    <div>
      <input
        className="border p-2"
        placeholder="GitHub username"
        onChange={(e) => setUsername(e.target.value)}
      />
      <button onClick={handleSubmit} className="ml-2 bg-black text-white px-4 py-2">
        Generate
      </button>
    </div>
  );
}
