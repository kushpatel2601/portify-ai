"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function Home() {
  const [username, setUsername] = useState("");
  const router = useRouter();

  const handleGenerate = () => {
    if (!username) return;
    router.push(`/portfolio?username=${username}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-black text-white flex flex-col">

      {/* Hero Section */}
      <div className="flex flex-col items-center justify-center flex-1 px-6 text-center">

        <h1 className="text-6xl font-extrabold mb-6 bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
          Portify 🚀
        </h1>

        <p className="text-xl text-gray-300 max-w-2xl mb-10">
          AI-powered Autonomous Resume-to-Portfolio Generator.  
          Convert any GitHub profile into a recruiter-ready professional portfolio in seconds.
        </p>

        {/* Input Card */}
        <div className="bg-slate-800 p-8 rounded-2xl shadow-2xl w-full max-w-xl border border-slate-700">

          <h2 className="text-2xl font-semibold mb-4">
            Enter GitHub Username
          </h2>

          <input
            type="text"
            placeholder="e.g. gaearon"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full px-4 py-3 rounded-lg bg-slate-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 mb-4"
          />

          <button
            onClick={handleGenerate}
            className="w-full bg-blue-600 hover:bg-blue-500 transition duration-300 py-3 rounded-lg font-semibold text-lg shadow-lg"
          >
            Generate Portfolio 🤖
          </button>
        </div>

        {/* Feature Section */}
        <div className="mt-16 grid md:grid-cols-3 gap-8 max-w-5xl">

          <div className="bg-slate-800 p-6 rounded-xl shadow-lg hover:scale-105 transition">
            <h3 className="text-xl font-bold mb-2">🤖 AI Repo Analyzer</h3>
            <p className="text-gray-400">
              Automatically analyzes repositories, extracts skills and evaluates code quality.
            </p>
          </div>

          <div className="bg-slate-800 p-6 rounded-xl shadow-lg hover:scale-105 transition">
            <h3 className="text-xl font-bold mb-2">✍️ Smart Storytelling</h3>
            <p className="text-gray-400">
              Converts technical projects into recruiter-friendly professional summaries.
            </p>
          </div>

          <div className="bg-slate-800 p-6 rounded-xl shadow-lg hover:scale-105 transition">
            <h3 className="text-xl font-bold mb-2">📊 ATS Optimization</h3>
            <p className="text-gray-400">
              Generates an ATS score and optimizes content for better hiring visibility.
            </p>
          </div>

        </div>

      </div>

      {/* Footer */}
      <div className="text-center py-6 text-gray-500 text-sm border-t border-slate-700">
        Built with ❤️ using Next.js, FastAPI & AI
      </div>

    </div>
  );
}
