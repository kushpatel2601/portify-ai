"use client";

import { useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";

export default function GeneratePage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const username = searchParams.get("username");

  useEffect(() => {
    async function generate() {
      if (!username) return;

      try {
        console.log("Sending POST request to backend...");

        const res = await fetch("http://localhost:8000/generate", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            github_username: username,
          }),
        });

        const data = await res.json();
        console.log("Backend response:", data);

        localStorage.setItem("portfolioData", JSON.stringify(data));

        router.push("/portfolio");
      } catch (error) {
        console.error("Error generating portfolio:", error);
      }
    }

    generate();
  }, [username, router]);

  return (
    <div className="flex items-center justify-center h-screen text-xl">
      🤖 Generating portfolio...
    </div>
  );
}
