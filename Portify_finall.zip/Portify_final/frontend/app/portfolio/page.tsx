"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { generatePortfolio } from "../../lib/api";
import SkillsGrid from "../../components/SkillsGrid";
import ATSScoreMeter from "../../components/ATSScoreMeter";

export default function Portfolio() {
  const searchParams = useSearchParams();
  const username = searchParams.get("username");

  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!username) return;

    const fetchData = async () => {
      try {
        const result = await generatePortfolio(username);
        setData(result);
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [username]);

  if (loading)
    return (
      <div className="flex items-center justify-center h-screen text-xl font-semibold">
        🤖 Generating Portfolio...
      </div>
    );

  if (!data)
    return <div className="p-10 text-center">No portfolio data found.</div>;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-white">
      
      {/* Hero Section */}
      <div className="text-center py-20 px-6">
        <h1 className="text-5xl font-bold tracking-wide">{data.username}</h1>
        <p className="mt-4 text-xl text-gray-300">{data.headline}</p>

        <div className="mt-8 flex justify-center">
          <ATSScoreMeter score={data.ats_score} />
        </div>
      </div>

      {/* About Section */}
      <div className="max-w-4xl mx-auto px-6 pb-16">
        <h2 className="text-3xl font-semibold mb-6 border-b border-gray-600 pb-2">
          About
        </h2>
        <p className="text-gray-300 leading-relaxed text-lg">
          {data.about}
        </p>
      </div>

      {/* Skills Section */}
      <div className="max-w-4xl mx-auto px-6 pb-16">
        <h2 className="text-3xl font-semibold mb-6 border-b border-gray-600 pb-2">
          Skills
        </h2>
        <SkillsGrid skills={data.skills} />
      </div>

      {/* Projects Section */}
      <div className="max-w-6xl mx-auto px-6 pb-20">
        <h2 className="text-3xl font-semibold mb-8 border-b border-gray-600 pb-2">
          Projects
        </h2>

        <div className="grid md:grid-cols-2 gap-8">
          {data.projects.map((project: any, index: number) => (
            <div
              key={index}
              className="bg-slate-700 rounded-xl p-6 shadow-lg hover:scale-105 transition duration-300"
            >
              <h3 className="text-2xl font-bold mb-2">{project.name}</h3>

              <p className="text-gray-300 mb-4">
                {project.description}
              </p>

              <div className="flex justify-between text-sm text-gray-400">
                <span>🛠 {project.language}</span>
                <span>⭐ {project.stars}</span>
              </div>

              <a
                href={project.url}
                target="_blank"
                className="inline-block mt-4 text-blue-400 hover:underline"
              >
                View on GitHub →
              </a>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
